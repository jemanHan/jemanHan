import type {Action} from 'redux'

export type State = any
export type Actions = Action
